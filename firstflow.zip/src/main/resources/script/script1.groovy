import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    
    try{
           def body = message.getBody(String.class)
           def messagelog = Imessagetogfactory.getMessageLog(message); 
           messagelog.addAttachmentAsString("Corpo da Mensagen", body, "text/plain"); 
    }catch (e) {

    }
    return message;
}